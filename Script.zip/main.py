import csv
import time
from pybit import HTTP


class ByBitAPI:

    def __init__(self, api_key, api_secret,filename):
        self.api_secret = api_secret
        self.api_key = api_key
        self.base_url = 'https://api.bybit.com'
        self.session = HTTP(api_key=self.api_key, api_secret=self.api_secret, logging_level=40)
        self.account_name = filename.replace('.csv','')

    def get_balance(self, coin="USDT"):
        try:
            return self.session.get_wallet_balance(coin=coin, spot=False)
        except Exception as e:
            print(f"Error occurred while getting the balance details for {self.account_name}")
            return None

    def write_data_to_csv(self, file_name, data):
        from os.path import exists

        file_exists = exists(file_name)
        with open(file_name, mode='a', newline='') as csv_file:
            employee_writer = csv.writer(csv_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            if not file_exists:
                employee_writer.writerow(
                    ['equity', 'available_balance', 'used_margin', 'order_margin', 'position_margin', 'occ_closing_fee',
                     'occ_funding_fee', 'wallet_balance', 'realised_pnl', 'unrealised_pnl', 'cum_realised_pnl',
                     'given_cash', 'service_cash'])

            employee_writer.writerow(data.values())

    def get_balance_http_url(self, coin="USDT"):
        import hmac
        from urllib.parse import urlencode
        timestamp = int(time.time() * 10 ** 3)
        query_args = {
            'api_key': self.api_key,
            'coin': coin,
            'timestamp': timestamp,
        }
        encoded_args = urlencode(query_args)
        signature = hmac.new(bytes(self.api_secret, 'utf-8'), bytes(encoded_args, 'utf-8'),
                             digestmod="sha256").hexdigest()
        url = "https://api.bybit.com/v2/private/wallet/balance?timestamp={}&api_key={}&sign={}&coin={}".format(
            timestamp,
            self.api_key,
            signature,
            coin)
        return url


def countdown(t):
    print(f"All done next iteration in {t/60} min")
    while t:
        mins, secs = divmod(t, 60)
        timer = '{:02d}:{:02d}'.format(mins, secs)
        print(timer, end="\r", flush=True)
        time.sleep(1)
        t -= 1


def main():
    with open('accounts.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            if line_count != 0:
                api_key = row[0]
                api_secret = row[1]
                file_name = row[2]
                print(f"Getting the details for {file_name.replace('.csv','')}")
                bybit_api = ByBitAPI(api_key, api_secret, file_name)
                response = bybit_api.get_balance()
                if response:
                    response = response['result']['USDT']
                else:
                    continue
                data = {
                    "equity": response['equity'],
                    "available_balance": response['available_balance'],
                    "used_margin": response['used_margin'],
                    "order_margin": response['order_margin'],
                    "position_margin": response['position_margin'],
                    "occ_closing_fee": response['occ_closing_fee'],
                    "occ_funding_fee": response['occ_funding_fee'],
                    "wallet_balance": response['wallet_balance'],
                    "realised_pnl": response['realised_pnl'],
                    "unrealised_pnl": response['unrealised_pnl'],
                    "cum_realised_pnl": response['cum_realised_pnl'],
                    "given_cash": response['given_cash'],
                    "service_cash": response['service_cash']
                }
                try:
                    print(f"Saving the details for {bybit_api.account_name}")
                    bybit_api.write_data_to_csv(file_name, data)
                except PermissionError:
                    print(f"Please close the file : {file_name}")
                except Exception as e:
                    print(f"Error occurred while saving the balance details for {bybit_api.account_name}: ERROR:{e}")
            line_count += 1


if __name__ == '__main__':
    while True:
        main()
        countdown(300)
